# alcuni capitoli

# I CAPITOLI PIÙ IMPORTANTI DEI PROMESSI SPOSI

## Capitolo I – Questo matrimonio non s’ha da fare

Il romanzo si apre con la presentazione dei luoghi che faranno da sfondo alle vicende: il lago di Lecco, i monti circostanti, i campi, le stradine di campagna, il fiume Adda e i paesi della Brianza. Fin da subito Manzoni inserisce una nota ironica sulla dominazione spagnola, descrivendo i soldati stranieri che approfittavano delle popolazioni locali con soprusi, violenze e ruberie.

La vicenda comincia il 7 novembre 1628. Don Abbondio, curato di un piccolo paese, sta tornando dalla sua consueta passeggiata serale leggendo il breviario. Giunto a un bivio vicino a un tabernacolo con l’immagine delle anime del purgatorio, scorge due uomini dall’aspetto minaccioso. Capisce immediatamente che sono bravi, uomini armati al servizio dei potenti, facilmente riconoscibili per l’abbigliamento e le armi. Nonostante le numerose grida contro di loro, i bravi continuarono a prosperare grazie alla protezione dei signorotti locali.

Don Abbondio, temendo per la propria vita, cerca di immaginare possibili vie di fuga o colpe che possano giustificare l’agguato, ma presto capisce che il bersaglio è lui. I due uomini gli si avvicinano e, con tono minaccioso, gli ordinano di non celebrare il matrimonio tra Renzo Tramaglino e Lucia Mondella. La celebre frase pronunciata è: «Questo matrimonio non s’ha da fare, né domani, né mai.» A terrorizzare ancora di più Don Abbondio è il nome del mandante: Don Rodrigo, potente signorotto locale invaghito di Lucia. Il curato, incapace di opporsi, promette obbedienza.

Disperato e sconvolto, Don Abbondio riflette sulla propria condizione: uomo debole e privo di coraggio, si era fatto prete non per vocazione ma per convenienza, per entrare in una classe sociale rispettata e al riparo dai conflitti. La sua intera vita era stata improntata a evitare i rischi, a schierarsi sempre con i più forti senza esporsi troppo. Ora, di fronte alla violenza dei bravi, si sente come un vaso di terracotta costretto a viaggiare tra vasi di ferro.

Rientrato a casa, non riesce a mascherare la paura davanti alla sua serva Perpetua. Nonostante il divieto imposto dai bravidi rivelare a chiunque l’accaduto, il curato, desideroso di conforto e incalzato dalla curiosità insistente della donna, finisce per confessare tutto. Perpetua lo sprona a rivolgersi all’arcivescovo, ma Don Abbondio rifiuta, temendo che il segreto possa diffondersi e aggravare la sua situazione. Alla fine si ritira sconsolato nella sua camera, raccomandando ancora una volta alla serva di mantenere il silenzio assoluto.

### Punti chiave del capitolo

Ambientazione: Lecco e i dintorni, sotto dominazione spagnola.

Don Abbondio: figura debole, prete per convenienza, timoroso e sottomesso ai potenti.

I bravi: esecutori di Don Rodrigo, minacciano il curato con la celebre frase.

Tema introdotto: il contrasto tra potere e debolezza, tra violenza e giustizia mancata.

Motivo della paura: Don Abbondio incarna la vigliaccheria e l’adattamento opportunistico di fronte all’ingiustizia.

### Domande di comprensione

Qual è il ruolo della dominazione spagnola nell’introduzione del romanzo?

Perché Don Abbondio viene minacciato dai bravi?

In che senso Don Abbondio è paragonato a un vaso di terracotta?

Quali sono le caratteristiche principali del suo carattere che emergono in questo capitolo?

## Capitolo IV – Fra Cristoforo

Il sole è appena sorto quando fra Cristoforo lascia il convento di Pescarenico, un piccolo villaggio di pescatori sulla riva sinistra dell’Adda, per recarsi a casa di Lucia. Il paesaggio autunnale, così suggestivo e sereno, non riesce a cancellare la desolazione che traspare dai volti incontrati lungo il cammino: ovunque si leggono i segni della fame, della miseria e della carestia che colpiscono la gente. Il frate cappuccino, sensibile alla sofferenza altrui, avanza con il cuore appesantito e con il timore di dover ascoltare una cattiva notizia.

### La storia di Fra Cristoforo

Per comprendere appieno la figura di fra Cristoforo è necessario conoscerne le origini.

Il suo vero nome era Ludovico, figlio di un ricco mercante che, accumulata una grande fortuna, aveva voluto rifarsi una vita da signore, nel tentativo di cancellare le proprie umili origini. Cresciuto in un ambiente raffinato e abituato agli onori, Ludovico non riuscì mai a integrarsi davvero con la nobiltà, che lo guardava con diffidenza e superbia. Quel rifiuto lo spinse ad assumere un atteggiamento di sfida: iniziò a proteggere i deboli e a opporsi alle prepotenze dei nobili, circondandosi però, per necessità, di bravi. La sua coscienza, già più volte turbata, gli suggeriva sempre più spesso la strada del convento.

Il destino si compì quando una banale disputa con un nobile arrogante per una questione di precedenza degenerò in tragedia: il nobile uccise il fedele servitore di Ludovico, di nome Cristoforo, e lo stesso Ludovico, accecato dall’ira, lo trafisse a morte. Costretto alla fuga, trovò rifugio presso i cappuccini. Lo strazio per la morte del servo e per il delitto compiuto lo convinsero che quell’episodio fosse un segno divino: donò tutti i suoi beni alla famiglia del servitore e intraprese la vita monastica, assumendo il nome di fra Cristoforo, in memoria dell’amico ucciso.

### La conversione

Prima di iniziare il noviziato, Ludovico volle incontrare la famiglia del nobile per chiedere perdono. Il fratello dell’ucciso organizzò una sorta di banchetto, convinto che la scelta del convento fosse dettata solo dalla paura. Ma l’umiltà sincera e il comportamento dignitoso del frate commossero tutti i presenti: la conversione apparve autentica e il perdono venne concesso. In segno di riconciliazione, il fratello del nobile gli donò un pane: fra Cristoforo ne conservò un pezzo per tutta la vita come ricordo tangibile della colpa e del perdono ricevuto.

### Un difensore degli oppressi

La vita da frate non spense in lui lo slancio verso la giustizia. Con il nuovo abito, Cristoforo continuò a combattere le ingiustizie, ma con spirito rinnovato: non più con la violenza e l’orgoglio, ma con l’umiltà e la forza morale della fede.

### L’arrivo da Lucia

Giunto infine alla casa di Lucia e di sua madre Agnese, il frate viene accolto con affetto e fiducia. In lui le due donne vedono non solo un uomo di Chiesa, ma un vero protettore, capace di difendere con coraggio gli umili contro le prepotenze dei potenti.

## Capitolo IX – La Monaca di Monza 1

Renzo, Lucia e Agnese, grazie all’imbarcazione predisposta da fra Cristoforo, attraversano il lago e raggiungono l’altra sponda. Dopo aver ringraziato il barcaiolo, riprendono subito il viaggio su un carro. Giunti a Monza all’alba, si fermano in un’osteria per fare colazione, poi si separano con dolore e speranza di potersi ritrovare presto: Renzo resta nella locanda per dirigersi successivamente a Milano, mentre Lucia e Agnese vengono accompagnate al convento dei cappuccini di Monza. Qui il padre guardiano le conduce, con cautela per evitare scandalo, al monastero della Signora, dove spera di ottenere ospitalità per loro.

Lucia e Agnese vengono introdotte nel parlatorio e incontrano Gertrude, la Monaca di Monza, giovane donna di circa venticinque anni, appartenente a una potente famiglia nobiliare. Il suo volto rivela una bellezza segnata e inquieta: lo sguardo e le labbra tradiscono un animo tormentato, oscillante tra superbia, ira, timidezza e paura. Anche il suo portamento e il modo di indossare il saio appaiono strani e inquietanti.

Gertrude vuole conoscere la storia delle due donne. Agnese inizia a parlare, ma viene subito interrotta dal padre guardiano, che racconta lui stesso i fatti in modo sobrio e senza dettagli. La curiosità della monaca resta insoddisfatta: sospettosa, interroga direttamente Lucia, insinuando un dubbio maligno sulla sua vicenda. La giovane, imbarazzata, non riesce a rispondere; solo dopo l’intervento della madre, e con grande sforzo, trova la forza di parlare e chiarire la situazione. Convinta dalla sincerità della ragazza, Gertrude accetta di offrire loro protezione, congedandosi poi dal frate e da Agnese e restando sola con Lucia.

### La storia di Gertrude

Per comprendere davvero il personaggio, occorre conoscerne la vicenda. Gertrude era l’ultima figlia di un potente principe feudatario di Monza. Il padre, deciso a conservare integro il patrimonio familiare, destinava tutti i figli cadetti e le figlie femmine alla vita religiosa, lasciando il titolo e le ricchezze al primogenito. Così, fin dall’infanzia, il destino di Gertrude era segnato: doveva farsi monaca.

La famiglia e le educatrici le inculcarono questa vocazione forzata con una vera manipolazione psicologica: bambole vestite da monache, santini come unici regali, rimproveri e lodi che alludevano a un futuro da badessa. A sei anni venne mandata al monastero di Monza per la sua istruzione: qui la badessa, desiderosa di mantenere i favori del principe, la colmò di privilegi per rendere desiderabile la vita claustrale. Tuttavia, i discorsi mondani delle coetanee sulle feste e i matrimoni destarono in lei curiosità e ribellione. Gertrude cominciò a rifiutare il destino impostole, e scrisse al padre manifestando la sua contrarietà. Non ricevette risposta: solo la badessa le fece intuire che il principe era furioso con lei.

Poco prima della professione religiosa, Gertrude trascorse un mese nella casa paterna. Ma quella che sperava fosse una parentesi di vita mondana si trasformò in una clausura ancora più dura: nessuno le rivolgeva la parola, non poteva uscire, durante i ricevimenti veniva relegata a tavola con la servitù. L’unico a mostrarle attenzione fu un giovane paggio, di cui s’invaghì. Una lettera scritta a lui cadde però nelle mani del padre, scatenando uno scandalo. Da allora la clausura si fece carcere: rinchiusa in una stanza, sorvegliata dalla donna che aveva scoperto la lettera, subì maltrattamenti e umiliazioni. L’odio reciproco con la carceriera e la disperazione la spinsero infine a piegarsi: pur di ottenere il perdono paterno e cambiare condizione, accettò la vita consacrata.

### Significato del personaggio

Gertrude rappresenta la tragedia di una vocazione forzata e della sopraffazione esercitata dal potere familiare. Dietro la veste monacale rimane una donna inquieta, ribelle e tormentata, incapace di conciliare la propria condizione con i desideri più autentici. Nel romanzo, la sua figura mostra le contraddizioni e le ingiustizie della società del Seicento, in cui perfino la religione viene usata come strumento di oppressione.

## Capitolo X – La Monaca di Monza 2

### La forzata monacazione

Il racconto sulla vita di Gertrude prosegue nel capitolo X. Colta in un momento di debolezza e ormai sopraffatta dalla volontà del padre, la giovane finisce per accettare la clausura. Viene quindi dato l’annuncio ufficiale della decisione e iniziano i festeggiamenti, come se fosse un evento lieto. Prima di condurla al monastero, il principe impartisce a Gertrude le ultime raccomandazioni: dovrà mostrarsi composta, rispondere con obbedienza e nascondere ogni dissenso.

### L’inganno della falsa vocazione

Arrivata in convento, Gertrude viene sottoposta a un colloquio formale con la badessa, volto a verificare la sincerità della sua vocazione. Tutto appare già deciso: la ragazza, per timore delle conseguenze e per la pressione paterna, non osa ribellarsi. Tornata a casa, sceglie la sua “madrina”, che l’accompagnerà alla cerimonia della monacazione. Il vicario incaricato di accertare la libertà della sua scelta la interroga: Gertrude, intimorita, mente e dichiara di voler abbracciare spontaneamente la vita religiosa. Così diventa “monaca per sempre” e maestra delle educande.

### La vita claustrale e le passioni terrene

Ma la vita nel chiostro non placa i turbamenti interiori della giovane. I primi anni sono segnati da ostilità verso le altre suore, odi reciproci e improvvisi cambiamenti d’umore. Gertrude, fragile e inquieta, cede infine al fascino di Egidio, un nobile che vive in una casa attigua al convento. Il loro rapporto segreto e peccaminoso trascina la monaca in una spirale di passioni violente. Sotto l’influenza nefasta di Egidio, Gertrude arriva persino a macchiarsi di un crimine terribile: l’omicidio di una conversa, complice involontaria della loro relazione.

### Ritorno alla vicenda di Lucia

A questo punto Manzoni interrompe la digressione biografica e ritorna al presente della narrazione. Gertrude, rimasta sola con Lucia, le rivolge domande maliziose e indiscrete sui suoi rapporti con Renzo e con Don Rodrigo, mostrando un atteggiamento ambiguo e inquietante. Lucia, turbata, confida le sue perplessità alla madre Agnese, che tuttavia cerca di rassicurarla. Infine, le due donne vengono accolte all’interno del monastero, ospitate nel quartiere della fattoressa, vicino al chiostro, e trattate come serve del convento.

### Temi chiave del capitolo

Vocazione forzata: la scelta religiosa non è frutto di libertà, ma di costrizione familiare e sociale.

Ipocrisia delle istituzioni: i colloqui di verifica risultano una pura formalità, incapaci di smascherare la costrizione.

Passioni e colpa: Gertrude incarna la fragilità umana e la discesa nel peccato, fino al delitto.

Ambiguità morale: la monaca diventa simbolo della corruzione di un sistema religioso e sociale che soffoca la libertà individuale.

### Glossario essenziale

Monacazione: rito con cui si emettono i voti religiosi, entrando definitivamente in convento.

Vocazione: chiamata interiore alla vita religiosa, che nel caso di Gertrude risulta assente.

Converso/a: persona che vive in convento ma senza emettere voti solenni, spesso con compiti di servizio.

Fattoressa: donna incaricata dell’amministrazione economica del monastero.

### Domande guida

Perché Gertrude accetta di entrare in convento? È una scelta libera?

In che modo il capitolo denuncia le pressioni sociali e familiari del tempo?

Cosa rappresenta il personaggio di Egidio nella vita della monaca?

Perché Lucia avverte disagio di fronte a Gertrude?

## LA CONVERSIONE DELL’INNOMINATO

La figura dell’Innominato è una delle più intense e drammatiche dei Promessi Sposi. Si tratta di un uomo ormai vicino ai sessant’anni, temuto da tutti, che ha costruito la sua esistenza sulla violenza e sul potere. Per lui la legge non ha mai rappresentato un limite: anzi, il suo piacere era proprio quello di violarla, affermando così la propria forza sugli altri. Attorno a lui regna il terrore: il suo castello, isolato e inaccessibile, è il simbolo stesso della sua vita oscura, fatta di delitti e sopraffazioni. Persino lo Stato lo lascia indisturbato, troppo pericoloso da affrontare apertamente.

Quando accetta di far rapire Lucia per compiacere Don Rodrigo, l’Innominato si trova di fronte a un’esperienza inattesa: quella giovane donna, innocente e indifesa, risveglia in lui qualcosa che da tempo era sepolto. All’arrivo della carrozza che trasporta Lucia, il signore malvagio pensa subito di liberarsi in fretta di quella prigioniera, consegnandola a Don Rodrigo. Ma la sua coscienza lo ferma: decide di tenerla con sé, come se avesse bisogno di tempo per capire. Invia allora una vecchia serva a confortarla e, poco dopo, va lui stesso a incontrarla. Trova Lucia rannicchiata a terra, che lo implora di lasciarla andare e pronuncia parole che lo colpiscono profondamente: “Dio perdona tante cose per un’opera di misericordia.” Quella frase semplice, venuta da una giovane terrorizzata, è come un seme che si insinua nel cuore del potente.

La notte che segue è per l’Innominato una vera agonia interiore. Rivede la sua vita, costellata di crimini e ingiustizie, e sente crescere un’angoscia insopportabile. Pensa persino al suicidio, ma il timore di un giudizio oltre la morte lo trattiene. La voce di Lucia, le sue parole di speranza e di perdono, continuano a risuonargli dentro. All’alba, quando sente lo scampanio festoso che annuncia la presenza del cardinale Federigo Borromeo nei villaggi vicini, decide di scendere a incontrarlo. È come se quella visita fosse un segno, un’occasione offerta per cambiare vita.

L’incontro con il cardinale segna il momento decisivo. Nonostante i timori del cappellano crocifero, che lo vorrebbe tenere lontano, Federigo accoglie l’Innominato senza esitazioni, lo abbraccia e lo ascolta. Quelle parole di accoglienza e di misericordia aprono una breccia definitiva nell’animo tormentato dell’uomo. L’Innominato scoppia in lacrime: è il segno della sua conversione. Da quel momento la sua vita prende una direzione completamente diversa. Decide di liberare Lucia, convoca i suoi bravi per annunciare il cambiamento e stabilisce che nei suoi domini non si commettano più violenze.

La storia dell’Innominato non è soltanto quella di un personaggio oscuro che trova la redenzione, ma è soprattutto la dimostrazione di come la Provvidenza sappia agire nei momenti più impensati, trasformando il cuore anche del più duro dei peccatori. Attraverso Lucia e poi attraverso l’incontro con Federigo Borromeo, l’uomo scopre la possibilità di un perdono e di una vita nuova, che sembrava impossibile.

# LEZIONE CONCLUSIVA

## Lezione conclusiva sulla letteratura manzoniana

### 1. La centralità di Manzoni nella letteratura italiana

Alessandro Manzoni occupa un posto fondamentale nella storia della letteratura italiana. Con la sua opera, in particolare I Promessi Sposi, egli ha dato vita al primo grande romanzo nazionale, capace di fondere insieme arte, storia e religione. Manzoni ha contribuito non solo a rinnovare i contenuti della letteratura, ma anche a definire la lingua italiana moderna, rendendola accessibile e comprensibile a un pubblico più ampio.

### 2. La poetica del vero, dell’utile e dell’interessante

Manzoni concepisce la letteratura come strumento educativo e civile. Il suo obiettivo non è solo intrattenere, ma formare il lettore attraverso il principio del vero in funzione dell’utile: la rappresentazione fedele della realtà storica e sociale serve a insegnare e a orientare le coscienze. L’arte deve dunque essere al tempo stesso vera, utile e interessante, unendo rigore storico, messaggio etico e forza narrativa.

### 3. La visione religiosa e la Provvidenza

Il nucleo della riflessione manzoniana è la presenza di Dio-Provvidenza nella storia. Nella prima fase del suo pensiero, influenzata dal giansenismo, la Provvidenza appare lontana e si manifesta solo nell’ultimo istante della vita dell’uomo. Successivamente, con gli Inni sacri e soprattutto con La Pentecoste e I Promessi Sposi, Manzoni giunge a una concezione più matura: Dio è sempre presente nella vita dell’uomo, anche attraverso la sventura, che diventa occasione di crescita morale e di conversione.

### 4. I generi e le opere

Le tragedie (Il Conte di Carmagnola, Adelchi): opere che rinnovano il teatro storico, sostituendo la retorica dell’eroismo con la meditazione morale e la denuncia delle ingiustizie.

Gli inni sacri: riflessione poetica sulla fede cristiana e sulla presenza di Dio nella storia.

Le odi civili (tra cui Marzo 1821 e Il cinque maggio): testimonianza del legame tra storia, politica e religione, con la celebre riflessione sulla gloria effimera di Napoleone e sulla consolazione divina.

I Promessi Sposi: il capolavoro assoluto, romanzo storico e religioso che unisce vicende individuali e destino collettivo, mostrando come la Provvidenza operi nel cuore della storia umana.

### 5. L’impegno linguistico

Con la “risciacquatura in Arno”, Manzoni elabora una lingua che possa essere davvero nazionale, scegliendo il fiorentino vivo come modello. Il suo lavoro linguistico contribuisce in modo decisivo alla formazione dell’italiano moderno e all’unità culturale del Paese.

### 6. Conclusione: l’eredità di Manzoni

La letteratura manzoniana si colloca all’incrocio tra fede, storia e coscienza civile. Essa non è evasione, ma responsabilità: la narrativa diventa uno strumento per comprendere il passato, giudicare il presente e costruire il futuro. Per questo, l’opera di Manzoni rimane ancora oggi un punto di riferimento imprescindibile, sia per la formazione letteraria sia per la riflessione etica e civile.

### Domande guida

In che modo Manzoni lega letteratura, fede e impegno civile?

Quale funzione educativa attribuisce al romanzo storico?

Perché I Promessi Sposi è considerato il primo vero romanzo nazionale italiano?
